<?php
// Connect to the database
$conn = new mysqli('127.0.0.1', 'root', '', 'newra14');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Initialize the error message variable
$error_message = "";

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];

    // Perform login validation based on user type
    $sql = "SELECT * FROM admin_details WHERE username = '$username' AND password = '$password' AND usertype = '$usertype'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        // Valid login, redirect to the respective user's page
        if ($usertype === 'admin') {
            header("Location: adminpage.php");
            exit();
        } 
        if ($usertype === 'staff') {
            header("Location: staff.php");
            exit();
        } 
    } else {
        // Invalid login, display an error message
        $error_message = "Invalid login credentials";
        header("Location: Adminlogin.php?error=" . urlencode($error_message));
        exit();
    }
    
}

$conn->close();
?>

